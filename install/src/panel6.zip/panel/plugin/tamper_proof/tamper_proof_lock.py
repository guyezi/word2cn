#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 邹浩文 <627622230@qq.com>
# +-------------------------------------------------------------------
#+--------------------------------------------------------------------
#|   宝塔防篡改程序
#+--------------------------------------------------------------------
import sys
sys.path.append('/www/server/panel/class')
import os,public,json,time

class BtLockFile():
    _PLUGIN_PATH = "/www/server/panel/plugin/tamper_proof"
    __CONFIG = '/config.json'
    _SITES = '/sites.json'
    _SITES_DATA = None
    __CONFIG_DATA = None
    _DONE_FILE = None
    bakcupChirdPath = []

    def LockFile(self):
        os.chdir("/www/server/panel")
        conffile = self._PLUGIN_PATH + self._SITES
        conf = json.loads(public.readFile(conffile))
        s = time.time()
        for i in conf:
            ed = ""
            for d in i["excludePath"]:
                ed += "/%s/|" % d
            ed = ed[:-1]
            if i["lock"] == "1":
                i["lock"] = "2"
                public.writeFile(conffile, json.dumps(conf))
                for e in i["protectExt"]:
                    os.system("find %s -name '*.%s'|grep -Ev '%s'|xargs chattr +i" % (i["path"], e ,ed))
                e = time.time() - s
                public.WriteLog(u"防篡改程序", u"网站[ %s ]防篡改锁定服务已成功启动,耗时[%s]秒" % (i["siteName"], e))
                break
            if i["lock"] == "3":
                i["lock"] = "0"
                public.writeFile(conffile, json.dumps(conf))
                for e in i["protectExt"]:
                    os.system("find %s -name '*.%s'|grep -Ev '%s'|xargs chattr -i" % (i["path"], e,ed))
                e = time.time() - s
                public.WriteLog(u"防篡改程序", u"网站[ %s ]防篡改锁定服务已成功关闭,耗时[%s]秒" % (i["siteName"], e))
                break
            if i["lock"] == "4":
                i["lock"] = "1"
                public.writeFile(conffile, json.dumps(conf))
                for e in i["protectExt"]:
                    os.system("find %s -name '*.%s'|grep -Ev '%s'|xargs chattr -i" % (i["path"], e,ed))
                e = time.time() - s
                public.WriteLog(u"防篡改程序", u"网站[ %s ]防篡改锁定服务已成功关闭,耗时[%s]秒" % (i["siteName"], e))
                continue

if __name__ == '__main__':
    l = BtLockFile()
    l.LockFile()